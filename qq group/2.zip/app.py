from flask import Flask, render_template, request, jsonify, send_file
from qq_group_api import QQGroupAPI
import jwt
import secrets
import threading
import time
import os

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)
JWT_SECRET = secrets.token_hex(32)

# 存储QQ号和登录状态的字典
# login_status[qq_number] = {
#   "status": "waiting_qr_scan" | "qr_scan_success_polling_groups" | "groups_verified_generating_token" | "success",
#   "qrsig": "some_qrsig_value", # Stored after QR is generated
#   "api_instance": api_instance, # Store the API instance for this session
#   "token": "jwt_token_if_success"
# }
login_sessions = {} # Renamed from login_status for clarity, and will store more state

def process_qq_login_and_get_groups(qq_number_str: str):
    """
    后台线程任务：
    1. 等待用户扫描二维码并登录 (调用 poll_scan_status_and_login)。
    2. 如果登录成功，获取群列表。
    3. 检查特定群ID。
    4. 如果群验证通过，生成JWT。
    """
    session_data = login_sessions.get(qq_number_str)
    if not session_data or "api_instance" not in session_data or "qrsig" not in session_data:
        print(f"[Thread-{qq_number_str}] 无效的会话数据或缺少api_instance/qrsig，终止线程。")
        if qq_number_str in login_sessions: # Clean up invalid session
            del login_sessions[qq_number_str]
        return

    api = session_data["api_instance"]
    qrsig = session_data["qrsig"]

    print(f"[Thread-{qq_number_str}] 开始轮询二维码扫描状态...")
    login_successful = api.poll_scan_status_and_login(qrsig)

    if not login_successful:
        print(f"[Thread-{qq_number_str}] QQ登录失败或二维码失效。")
        login_sessions[qq_number_str]["status"] = "login_failed"
        # Consider removing the session here or letting it timeout/be cleaned by user action
        return

    print(f"[Thread-{qq_number_str}] QQ登录成功，开始获取群列表...")
    login_sessions[qq_number_str]["status"] = "qr_scan_success_polling_groups"
    groups = api.get_joined_groups()
    
    if not groups:
        print(f"[Thread-{qq_number_str}] 未能获取到群列表，或用户未加入任何群。")
        login_sessions[qq_number_str]["status"] = "group_check_failed_no_groups"
        return

    found_target_group = False
    for group in groups:
        if group.group_id == "192541791":  # 目标群ID
            found_target_group = True
            break
    
    if found_target_group:
        print(f"[Thread-{qq_number_str}] 用户在目标群中，生成Token...")
        try:
            token = jwt.encode(
                {"qq": qq_number_str, "exp": time.time() + 3600 * 24},  # Token有效期24小时
                JWT_SECRET,
                algorithm="HS256"
            )
            login_sessions[qq_number_str]["status"] = "success"
            login_sessions[qq_number_str]["token"] = token
            print(f"[Thread-{qq_number_str}] Token生成成功。")
        except Exception as e:
            print(f"[Thread-{qq_number_str}] Token生成失败: {e}")
            login_sessions[qq_number_str]["status"] = "token_generation_failed"
    else:
        print(f"[Thread-{qq_number_str}] 用户不在目标群 (192541791) 中。")
        login_sessions[qq_number_str]["status"] = "group_check_failed_not_in_group"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/qq_login_qr.png')
def get_qr():
    qr_path = "qq_login_qr.png"
    if os.path.exists(qr_path):
        return send_file(qr_path, mimetype='image/png', as_attachment=False, download_name='qq_login_qr.png')
    else:
        # print("二维码图片文件不存在") # 调试时可以取消注释
        return "QR code not found or not yet generated", 404

@app.route('/login', methods=['POST'])
def login_initiate():
    qq_number = request.form.get('qq_number')
    if not qq_number:
        return jsonify({"error": "请输入QQ号"}), 400
    
    if qq_number in login_sessions and login_sessions[qq_number].get("status") not in ["login_failed", "group_check_failed_no_groups", "group_check_failed_not_in_group", "token_generation_failed", "success"]:
        # 如果已有进行中的会话（非最终失败或成功状态），可以提示用户
        # 或者，也可以选择终止旧线程并开始新的。此处简单返回错误。
        print(f"QQ号 {qq_number} 已有一个正在进行的登录会话。状态: {login_sessions[qq_number].get('status')}")
        return jsonify({"error": "您已有一个正在进行的登录会话，请稍后再试或完成当前验证。", "status_code": login_sessions[qq_number].get('status')}), 409 # 409 Conflict

    api = QQGroupAPI() # 每个登录会话创建一个新的API实例
    print(f"为QQ号 {qq_number} 初始化二维码生成...")
    qrsig = api.initiate_qr_and_get_qrsig()

    if qrsig:
        print(f"二维码已生成，qrsig: {qrsig}。为QQ号 {qq_number} 启动后台检查线程。")
        login_sessions[qq_number] = {
            "status": "waiting_qr_scan", 
            "qrsig": qrsig,
            "api_instance": api, # 将API实例与会话关联
            "timestamp": time.time()
        }
        
        thread = threading.Thread(target=process_qq_login_and_get_groups, args=(qq_number,))
        thread.daemon = True # 确保主程序退出时线程也退出
        thread.start()
        
        return jsonify({"status": "qr_generated_waiting_scan", "message": "二维码已生成，请扫描"})
    else:
        print(f"为QQ号 {qq_number} 生成二维码失败。")
        # 清理可能创建的部分会话数据
        if qq_number in login_sessions:
            del login_sessions[qq_number]
        return jsonify({"error": "二维码生成失败，请重试"}), 500

@app.route('/check_status', methods=['POST'])
def check_login_status_endpoint(): # Renamed to avoid conflict with function name
    qq_number = request.form.get('qq_number')
    if not qq_number:
        return jsonify({"status": "error", "message": "请求中未提供QQ号"}), 400

    session_data = login_sessions.get(qq_number)

    if not session_data:
        return jsonify({"status": "error", "message": "无效的会话或会话已过期/未找到"}), 404

    current_status = session_data.get("status")
    
    if current_status == "success":
        token = session_data.get("token")
        print(f"状态检查：QQ号 {qq_number} 验证成功，返回Token。")
        # 验证成功后，可以选择清理会话或保留一段时间供用户多次查询
        # del login_sessions[qq_number] # 如果只允许获取一次token
        return jsonify({"status": "success", "token": token, "message": "验证成功！"})
    
    elif current_status in ["login_failed", "group_check_failed_no_groups", "group_check_failed_not_in_group", "token_generation_failed"]:
        error_message_map = {
            "login_failed": "QQ登录失败或二维码已失效，请重试。",
            "group_check_failed_no_groups": "未能获取到您的群列表，或您未加入任何群组。",
            "group_check_failed_not_in_group": f"您不在目标群 (192541791) 中。",
            "token_generation_failed": "Token生成时发生内部错误，请联系管理员。"
        }
        print(f"状态检查：QQ号 {qq_number} 验证失败。状态: {current_status}")
        # 失败后清理会话
        if qq_number in login_sessions:
             del login_sessions[qq_number]
        return jsonify({"status": "error", "message": error_message_map.get(current_status, "验证失败，请重试。")}), 401 # 401 Unauthorized or specific error
    
    # 其他进行中的状态 ("waiting_qr_scan", "qr_scan_success_polling_groups")
    message_map = {
        "waiting_qr_scan": "等待扫描二维码...",
        "qr_scan_success_polling_groups": "扫码成功，正在验证群信息..."
    }
    print(f"状态检查：QQ号 {qq_number} 仍在验证中。状态: {current_status}")
    return jsonify({"status": "pending", "message": message_map.get(current_status, "处理中...")})

# 添加一个简单的清理过期会话的逻辑 (可选)
# def cleanup_expired_sessions():
#     while True:
#         time.sleep(60 * 5) # 每5分钟检查一次
#         now = time.time()
#         expired_keys = []
#         for qq, data in login_sessions.items():
#             # 清理超过30分钟未成功的会话, 或已失败/成功的会话（如果它们没有被其他逻辑删除）
#             session_age = now - data.get("timestamp", now)
#             is_final_state = data.get("status") in ["success", "login_failed", "group_check_failed_no_groups", "group_check_failed_not_in_group", "token_generation_failed"]
#             if (session_age > 1800 and not is_final_state) or (is_final_state and session_age > 300): # 成功/失败的会话保留5分钟供查询
#                 expired_keys.append(qq)
#         for key in expired_keys:
#             if key in login_sessions:
#                 print(f"清理过期或已完成的会话: {key}")
#                 del login_sessions[key]

if __name__ == '__main__':
    # cleanup_thread = threading.Thread(target=cleanup_expired_sessions)
    # cleanup_thread.daemon = True
    # cleanup_thread.start()
    app.run(debug=True, port=5000) # debug=True时，Flask通常使用单线程，对于多线程任务可能有影响
                                   # 如果遇到线程问题，可以考虑 app.run(debug=False, threaded=True, port=5000)
                                   # 或者使用生产级的WSGI服务器如Gunicorn 